#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
通用 Excel 转 JSON 工具
- 类型定义在第二行
- 第三行为注释（忽略）
- 第四行开始为数据
- # 开头的 sheet 为引用表
"""

import sys

# Windows 输出缓冲修复
try:
    sys.stdout.reconfigure(line_buffering=True)
except:
    pass

import json
import openpyxl
import os
from typing import Any, Dict, List, Optional


def parse_bool(value: Any) -> Any:
    """解析布尔值"""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        if value.upper() == 'TRUE':
            return True
        if value.upper() == 'FALSE':
            return False
    return value


def parse_int(value: Any) -> Any:
    """解析整数"""
    if value is None or value == '':
        return None
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str):
        try:
            return int(float(value))  # 处理 "1.0" 这种情况
        except ValueError:
            return value
    return value


def parse_float(value: Any) -> Any:
    """解析浮点数"""
    if value is None or value == '':
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return value
    return value


def parse_map_number(value: Any) -> Dict[str, Any]:
    """解析 MapNumber 类型: 'key:value\nkey:value' -> {key: value}"""
    if not value or not isinstance(value, str):
        return {}
    result = {}
    for item in value.split('\n'):
        item = item.strip()
        if ':' in item:
            key, val = item.split(':', 1)
            key = key.strip()
            val = val.strip()
            # 尝试转换为数字
            try:
                val = float(val) if '.' in val else int(val)
            except ValueError:
                pass
            result[key] = val
    return result


def parse_map_any(value: Any) -> Dict[str, Any]:
    """解析 MapAny 类型: 'key:value\nkey:value' -> {key: value}
    值可能是数字、布尔值、字符串或数组(JSON格式)
    """
    if not value or not isinstance(value, str):
        return {}
    result = {}
    for item in value.split('\n'):
        item = item.strip()
        if ':' in item:
            key, val = item.split(':', 1)
            key = key.strip()
            val = val.strip()

            # 尝试解析数组（JSON格式）
            if val.startswith('[') and val.endswith(']'):
                try:
                    val = json.loads(val)
                except json.JSONDecodeError:
                    pass  # 保持字符串
            # 尝试解析布尔值
            elif val.lower() == 'true':
                val = True
            elif val.lower() == 'false':
                val = False
            else:
                try:
                    val = float(val) if '.' in val else int(val)
                except ValueError:
                    pass  # 保持字符串
            result[key] = val
    return result


def parse_string_array(value: Any) -> List[str]:
    """解析 string[] 类型: 支持换行符或分号分隔"""
    if not value or not isinstance(value, str):
        return []
    # 先按换行符分割，如果结果太少再按分号分割
    parts = value.split('\n')
    if len(parts) == 1 and ';' in value:
        parts = value.split(';')
    return [item.strip() for item in parts if item.strip()]


def find_hash_sheet(wb: openpyxl.Workbook, column_name: str) -> Optional[str]:
    """根据列名查找对应的 #Sheet"""
    # 直接匹配
    if f'#{column_name}' in wb.sheetnames:
        return f'#{column_name}'

    # 获取列名的单数形式（去掉结尾的 s）
    singular = column_name[:-1] if column_name.endswith('s') else column_name
    if f'#{singular}' in wb.sheetnames:
        return f'#{singular}'

    # 模糊匹配：检查 sheet 名（去掉 #）是否在列名中，或列名是否在 sheet 名中
    for sheet_name in wb.sheetnames:
        if sheet_name.startswith('#'):
            sheet_base = sheet_name[1:].lower()
            col_lower = column_name.lower()
            # 匹配：#Option 匹配 options，options 匹配 #Option
            if sheet_base in col_lower or col_lower in sheet_base:
                return sheet_name
    return None


def get_data_from_hash_sheet(wb: openpyxl.Workbook, column_name: str, data_id: str) -> Optional[Dict]:
    """从 #Sheet 中获取指定 id 的数据（不包含 id 字段），递归解析嵌套的 data/data[] 引用"""
    sheet_name = find_hash_sheet(wb, column_name)
    if not sheet_name:
        return None

    ws = wb[sheet_name]

    # 数据起始行固定为第4行
    start_row = 4

    # 获取列名（第1行）
    headers = []
    for col in range(1, ws.max_column + 1):
        val = ws.cell(row=1, column=col).value
        if val:
            headers.append(str(val))
        else:
            break

    # 获取类型（第2行）
    types = []
    for col in range(1, len(headers) + 1):
        types.append(ws.cell(row=2, column=col).value)

    # 查找数据行
    for row_idx in range(start_row, ws.max_row + 1):
        # 跳过空行（id 列为空）
        id_cell_value = ws.cell(row=row_idx, column=1).value
        if not id_cell_value:
            continue

        if id_cell_value == data_id:
            row_data = {}
            for col_idx, (header, typ) in enumerate(zip(headers, types), 1):
                val = ws.cell(row=row_idx, column=col_idx).value
                if val is None or val == '':
                    continue

                # 跳过 id 列（引用表不需要导出 id）
                if header == 'id':
                    continue

                # 处理 data 类型（嵌套引用）
                if typ and typ.strip().lower() == 'data':
                    ref_data = get_data_from_hash_sheet(wb, header, val)
                    if ref_data:
                        row_data[header] = ref_data
                    else:
                        row_data[header] = val
                elif typ and typ.strip().lower() == 'data[]':
                    # 多个引用值，解析为 id 数组后逐个获取数据
                    id_list = parse_string_array(val)
                    ref_list = []
                    for id_val in id_list:
                        ref_data = get_data_from_hash_sheet(wb, header, id_val)
                        if ref_data:
                            ref_list.append(ref_data)
                        else:
                            ref_list.append(id_val)
                    row_data[header] = ref_list
                else:
                    # 根据类型解析
                    parsed_val = parse_value_by_type(val, typ)
                    row_data[header] = parsed_val

            return row_data

    return None


def parse_value_by_type(value: Any, type_name: str) -> Any:
    """根据类型名称解析值"""
    if value is None or value == '':
        return None

    type_name = (type_name or '').strip().lower()

    if type_name == 'bool':
        return parse_bool(value)
    elif type_name == 'int':
        return parse_int(value)
    elif type_name == 'float':
        return parse_float(value)
    elif type_name == 'mapnumber':
        return parse_map_number(value)
    elif type_name == 'mapany':
        return parse_map_any(value)
    elif type_name == 'string[]':
        return parse_string_array(value)
    elif type_name == 'data':
        # data 类型需要在调用处处理
        return value
    else:
        # 默认为 string
        return value


def process_sheet(wb: openpyxl.Workbook, sheet_name: str, output: Dict) -> None:
    """处理单个 sheet"""
    if sheet_name.startswith('#'):
        return  # 跳过引用表

    ws = wb[sheet_name]

    # 获取列名（第1行）
    headers = []
    for col in range(1, ws.max_column + 1):
        val = ws.cell(row=1, column=col).value
        if val:
            headers.append(str(val))
        else:
            break

    if not headers:
        return

    # 获取类型（第2行）
    types = []
    for col in range(1, len(headers) + 1):
        types.append(ws.cell(row=2, column=col).value)

    # 数据起始行固定为第4行
    start_row = 4

    # 解析数据行
    data_list = []
    for row_idx in range(start_row, ws.max_row + 1):
        # 检查 id 列是否有值，空行跳过
        id_val = ws.cell(row=row_idx, column=1).value
        if not id_val:
            continue

        # 检查整行是否为空（所有列都无值）
        row_is_empty = True
        for col_idx in range(1, len(headers) + 1):
            cell_val = ws.cell(row=row_idx, column=col_idx).value
            if cell_val is not None and str(cell_val).strip() != '':
                row_is_empty = False
                break
        if row_is_empty:
            continue

        row_data = {}
        for col_idx, (header, typ) in enumerate(zip(headers, types), 1):
            val = ws.cell(row=row_idx, column=col_idx).value

            if val is None or val == '':
                continue

            # 处理 data 类型（引用其他表）
            if typ and typ.strip().lower() == 'data':
                # 单个引用值，从对应的 #sheet 获取数据
                ref_data = get_data_from_hash_sheet(wb, header, val)
                if ref_data:
                    row_data[header] = ref_data
                else:
                    row_data[header] = val
            elif typ and typ.strip().lower() == 'data[]':
                # 多个引用值，解析为 id 数组后逐个获取数据
                id_list = parse_string_array(val)
                ref_list = []
                for id_val in id_list:
                    ref_data = get_data_from_hash_sheet(wb, header, id_val)
                    if ref_data:
                        ref_list.append(ref_data)
                    else:
                        ref_list.append(id_val)
                row_data[header] = ref_list
            else:
                # 根据类型解析
                parsed_val = parse_value_by_type(val, typ)
                row_data[header] = parsed_val

        data_list.append(row_data)

    if data_list:
        output[sheet_name] = data_list


def excel_to_json(excel_path: str, output_dir: Optional[str] = None) -> List[Dict]:
    """将 Excel 文件转换为 JSON"""
    # 检查文件是否为有效的 Excel 文件
    if not os.path.exists(excel_path):
        raise FileNotFoundError(f"文件不存在: {excel_path}")

    # 检查文件大小，空文件或过小的文件可能无效
    file_size = os.path.getsize(excel_path)
    if file_size == 0:
        raise ValueError(f"文件为空: {excel_path}")

    try:
        wb = openpyxl.load_workbook(excel_path, data_only=True)
    except OSError as e:
        if "workbook part" in str(e):
            # 检查是否是 .xls 格式
            with open(excel_path, 'rb') as f:
                header = f.read(8)
                is_xls = header == b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'
                is_zip = header[:4] == b'PK\x03\x04'

            if is_xls:
                raise ValueError(f"不支持的文件格式: {excel_path}\n"
                               f"此文件是 .xls 格式（旧版 Excel），但本工具只支持 .xlsx 格式。\n"
                               f"解决方法：用 Excel/WPS 打开文件，另存为 .xlsx 格式") from e
            else:
                raise ValueError(f"无效的 Excel 文件: {excel_path}\n"
                               f"可能原因:\n"
                               f"  1. 文件不是 .xlsx 格式（可能是 CSV、TXT 等格式）\n"
                               f"  2. 文件已损坏\n"
                               f"  3. 文件正在被其他程序占用") from e
        raise

    results = {}

    # 遍历所有非 # 开头的 Sheet
    for sheet_name in wb.sheetnames:
        if sheet_name.startswith('#'):
            continue
        process_sheet(wb, sheet_name, results)

    # 输出 JSON
    if output_dir is None:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_dir = os.path.join(script_dir, '../Assets/Data/Resources/Json')

    # 保持相对路径，如果需要绝对路径可以取消注释下面这行
    # output_dir = os.path.abspath(output_dir)

    os.makedirs(output_dir, exist_ok=True)

    base_name = os.path.splitext(os.path.basename(excel_path))[0]
    # 将 Config 后缀去掉，如 ChapterConfig -> Chapter
    if base_name.endswith('Config'):
        base_name = base_name[:-6]  # 去掉 'Config'
    # 首字母小写
    file_name = base_name[0].lower() + base_name[1:] if base_name else base_name.lower()

    output_path = os.path.join(output_dir, f'{file_name}.json')

    # 导出为纯数组格式: [{}]
    # 只取第一个主表的数据
    data_to_export = None
    for key in results:
        data_to_export = results[key]
        break

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(data_to_export, f, ensure_ascii=False, indent=2)

    return data_to_export


def main(file_name: Optional[str] = None):
    """
    导出 Excel 为 JSON

    Args:
        file_name: Excel 文件名，不填则导出所有文件
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_dir = os.path.join(script_dir, 'excel')
    output_dir = os.path.join(script_dir, '../Assets/Data/Resources/Json')

    # 保持相对路径，如果需要绝对路径可以取消注释下面这行
    # output_dir = os.path.abspath(output_dir)

    print('=' * 50, flush=True)
    print('Excel to JSON Converter', flush=True)
    print('=' * 50, flush=True)
    print(f'Output directory: {output_dir}', flush=True)

    # 确定要处理的文件列表
    if file_name:
        excel_files = [file_name]
        print(f'Mode: Single file ({file_name})', flush=True)
    else:
        excel_files = [f for f in os.listdir(excel_dir) if f.endswith('.xlsx') and not f.startswith('.~')]
        print(f'Mode: Batch export ({len(excel_files)} files)', flush=True)

    print('=' * 50, flush=True)

    success_count = 0
    for excel_file in excel_files:
        # 确保 .xlsx 后缀
        if not excel_file.endswith('.xlsx'):
            excel_file += '.xlsx'

        excel_path = os.path.join(excel_dir, excel_file)
        if os.path.exists(excel_path):
            print(f'Processing: {excel_file}...', end=' ', flush=True)
            try:
                data = excel_to_json(excel_path, output_dir)
                # 显示导出的数据条数
                if data:
                    count = len(data) if isinstance(data, list) else 0
                    print(f'OK ({count} records)', flush=True)
                else:
                    print('OK (0 records)', flush=True)
                success_count += 1
            except FileNotFoundError as e:
                print(f'\n  [错误] {e}', flush=True)
            except ValueError as e:
                print(f'\n  [错误] {e}', flush=True)
            except Exception as e:
                print(f'\n  [错误] 处理失败: {e}', flush=True)
                import traceback
                traceback.print_exc()
        else:
            print(f'SKIPPED (file not found): {excel_path}', flush=True)

    print('=' * 50, flush=True)
    print(f'Done! Success: {success_count}/{len(excel_files)} files', flush=True)
    print('=' * 50, flush=True)


if __name__ == '__main__':
    # 填文件名则导出指定文件，不填则导出全部
    main()
