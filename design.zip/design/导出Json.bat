@echo off
chcp 65001 >nul
cd /d "%~dp0"

python -c "import openpyxl" 2>nul
if errorlevel 1 (
    echo [INFO] Installing openpyxl...
    pip install openpyxl -q
)

python generic_excel_to_json.py
if errorlevel 1 (
    echo.
    echo [ERROR] Script failed
)
pause