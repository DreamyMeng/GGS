#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
根据 Excel 表头生成 C# 类定义工具
- 读取 Excel 的列名（第1行）和类型（第2行）
- 生成对应的 C# 类文件
"""

import sys
import os
import openpyxl
from typing import Dict, List, Optional, Set


# C# 类型映射表
TYPE_MAPPING = {
    'string': 'string',
    'int': 'int',
    'float': 'float',
    'bool': 'bool',
    'mapnumber': 'Dictionary<string, int>',
    'mapany': 'Dictionary<string, object>',
    'string[]': 'List<string>',
    'int[]': 'List<int>',
    'float[]': 'List<float>',
    'data': 'object',  # 嵌套对象，具体类型需要根据列名推断
    'data[]': 'List<object>',
}

# 需要添加 using 的类型
USING_TYPES = {
    'Dictionary<string, int>': 'System.Collections.Generic',
    'Dictionary<string, object>': 'System.Collections.Generic',
    'Dictionary<string, string>': 'System.Collections.Generic',
    'List<string>': 'System.Collections.Generic',
    'List<int>': 'System.Collections.Generic',
    'List<float>': 'System.Collections.Generic',
    'List<object>': 'System.Collections.Generic',
}


def get_csharp_type(excel_type: str, column_name: str) -> tuple:
    """
    将 Excel 类型转换为 C# 类型
    返回: (csharp_type, is_nullable, using_namespace)
    """
    if not excel_type:
        excel_type = 'string'

    type_lower = excel_type.strip().lower()

    # 检查是否是数组类型
    is_array = type_lower.endswith('[]')
    base_type = type_lower[:-2] if is_array else type_lower

    # 处理 data 类型 - 根据列名推断类型
    if base_type == 'data':
        # 尝试从列名推断类型
        inferred_type = infer_type_from_column_name(column_name)
        if is_array:
            csharp_type = f'List<{inferred_type}>'
        else:
            csharp_type = inferred_type
        is_nullable = True
    elif base_type in TYPE_MAPPING:
        mapped = TYPE_MAPPING[base_type]
        if is_array and not mapped.startswith('List'):
            # 为基本类型添加数组
            csharp_type = f'List<{mapped}>'
        else:
            csharp_type = mapped
        is_nullable = base_type not in ('bool',)
    else:
        # 未知类型，默认为 string
        csharp_type = 'string'
        is_nullable = True

    # 获取 using 命名空间
    using_ns = None
    for generic_type, ns in USING_TYPES.items():
        if generic_type in csharp_type:
            using_ns = ns
            break

    return csharp_type, is_nullable, using_ns


def infer_type_from_column_name(column_name: str) -> str:
    """根据列名推断类型"""
    if not column_name:
        return 'object'

    column_lower = column_name.lower()

    # 常见后缀映射
    type_mappings = {
        'id': 'int',
        'count': 'int',
        'num': 'int',
        'level': 'int',
        'index': 'int',
        'score': 'int',
        'hp': 'int',
        'mp': 'int',
        'exp': 'int',
        'damage': 'int',
        'defense': 'int',
        'speed': 'float',
        'rate': 'float',
        'percent': 'float',
        'probability': 'float',
        'price': 'int',
        'cost': 'int',
        'value': 'int',
        'amount': 'int',
        'quantity': 'int',
        'enabled': 'bool',
        'active': 'bool',
        'visible': 'bool',
        'locked': 'bool',
        'name': 'string',
        'desc': 'string',
        'description': 'string',
        'text': 'string',
        'icon': 'string',
        'path': 'string',
        'url': 'string',
        'color': 'string',
        'position': 'Vector3',
        'rotation': 'Quaternion',
        'scale': 'Vector3',
    }

    for suffix, type_name in type_mappings.items():
        if column_lower.endswith(suffix):
            return type_name

    # 特殊前缀
    if column_lower.startswith('is'):
        return 'bool'
    if column_lower.startswith('has'):
        return 'bool'

    return 'object'


def to_pascal_case(name: str) -> str:
    """转换为 PascalCase"""
    if not name:
        return name

    # 处理下划线命名
    parts = name.replace('_', ' ').split()
    return ''.join(word.capitalize() for word in parts)


def to_camel_case(name: str) -> str:
    """转换为 camelCase"""
    pascal = to_pascal_case(name)
    if not pascal:
        return pascal
    return pascal[0].lower() + pascal[1:]


def escape_if_keyword(name: str) -> str:
    """如果 name 是 C# 关键字，添加 @ 前缀"""
    keywords = {
        'abstract', 'as', 'base', 'bool', 'break', 'byte', 'case', 'catch',
        'char', 'checked', 'class', 'const', 'continue', 'decimal', 'default',
        'delegate', 'do', 'double', 'else', 'enum', 'event', 'explicit',
        'extern', 'false', 'finally', 'fixed', 'float', 'for', 'foreach',
        'goto', 'if', 'implicit', 'in', 'int', 'interface', 'internal', 'is',
        'lock', 'long', 'namespace', 'new', 'null', 'object', 'operator',
        'out', 'override', 'params', 'private', 'protected', 'public', 'readonly',
        'ref', 'return', 'sbyte', 'sealed', 'short', 'sizeof', 'stackalloc',
        'static', 'string', 'struct', 'switch', 'this', 'throw', 'true', 'try',
        'typeof', 'uint', 'ulong', 'unchecked', 'unsafe', 'ushort', 'using',
        'virtual', 'void', 'volatile', 'while'
    }
    if name in keywords:
        return '@' + name
    return name


def generate_class_code(
    sheet_name: str,
    headers: List[str],
    types: List[str],
    namespace: str = 'Game.Config',
    base_class: Optional[str] = None
) -> str:
    """生成 C# 类代码"""

    using_namespaces: Set[str] = {'System', 'System.Collections.Generic'}
    properties = []

    for header, typ in zip(headers, types):
        if not header:
            continue

        csharp_type, is_nullable, using_ns = get_csharp_type(typ, header)
        if using_ns:
            using_namespaces.add(using_ns)

        property_name = escape_if_keyword(to_pascal_case(header))
        summary = f'/// <summary>\n        /// {header}\n        /// </summary>'

        # 为引用类型添加可空标记
        if is_nullable and not csharp_type.endswith('?'):
            type_with_nullable = csharp_type
        else:
            type_with_nullable = csharp_type

        properties.append(f'{summary}\n        public {type_with_nullable} {property_name} {{ get; set; }}')

    # 添加 Vector using
    if any('Vector' in prop or 'Quaternion' in prop for prop in properties):
        using_namespaces.add('UnityEngine')

    # 生成 using 语句
    using_block = '\n'.join(f'using {ns};' for ns in sorted(using_namespaces))

    # 生成类定义
    class_name = to_pascal_case(sheet_name)
    if class_name.endswith('Config'):
        class_name = class_name[:-6]  # 去掉 Config 后缀

    base_class_clause = f' : {base_class}' if base_class else ''

    code = f'''{using_block}

namespace {namespace}
{{
    /// <summary>
    /// {sheet_name} 配置数据
    /// </summary>
    [System.Serializable]
    public class {class_name}{base_class_clause}
    {{
{chr(10).join(properties)}
    }}
}}'''

    return code


def generate_manager_code(
    class_name: str,
    sheet_name: str,
    namespace: str = 'Game.Config'
) -> str:
    """生成配置管理器代码"""

    manager_name = f'{class_name}Manager'
    config_list_name = f'{class_name}ConfigList'

    code = f'''using System;
using System.Collections.Generic;
using UnityEngine;

namespace {namespace}
{{
    /// <summary>
    /// {sheet_name} 配置管理器
    /// </summary>
    public class {manager_name} : ScriptableObject
    {{
        private static {manager_name} _instance;

        public static {manager_name} Instance
        {{
            get
            {{
                if (_instance == null)
                {{
                    // 从 Resources 加载
                    _instance = Resources.Load<{manager_name}>("Config/{manager_name}");
                    if (_instance == null)
                    {{
                        Debug.LogError("{{{manager_name}}} not found in Resources/Config/");
                    }}
                }}
                return _instance;
            }}
        }}

        [SerializeField]
        private List<{class_name}> _configs = new List<{class_name}>();

        private Dictionary<string, {class_name}> _configDict;

        private void OnEnable()
        {{
            Initialize();
        }}

        public void Initialize()
        {{
            if (_configDict != null)
                return;

            _configDict = new Dictionary<string, {class_name}>();
            foreach (var config in _configs)
            {{
                // 假设 id 是主键
                var idField = config.GetType().GetProperty("id");
                if (idField != null)
                {{
                    var id = idField.GetValue(config)?.ToString();
                    if (!string.IsNullOrEmpty(id))
                    {{
                        _configDict[id] = config;
                    }}
                }}
            }}
        }}

        public {class_name} GetConfig(string id)
        {{
            Initialize();
            _configDict.TryGetValue(id, out var config);
            return config;
        }}

        public List<{class_name}> GetAllConfigs()
        {{
            return new List<{class_name}>(_configs);
        }}

        public bool Contains(string id)
        {{
            Initialize();
            return _configDict.ContainsKey(id);
        }}
    }}
}}'''

    return code


def process_excel_file(
    excel_path: str,
    output_dir: str,
    namespace: str = 'Game.Config',
    generate_manager: bool = True
) -> List[str]:
    """处理单个 Excel 文件，生成 C# 类文件"""

    wb = openpyxl.load_workbook(excel_path, data_only=True)
    generated_files = []

    for sheet_name in wb.sheetnames:
        if sheet_name.startswith('#'):
            continue  # 跳过引用表

        ws = wb[sheet_name]

        # 读取表头（第1行）
        headers = []
        for col in range(1, ws.max_column + 1):
            val = ws.cell(row=1, column=col).value
            if val:
                headers.append(str(val))
            else:
                break

        if not headers:
            continue

        # 读取类型（第2行）
        types = []
        for col in range(1, len(headers) + 1):
            types.append(ws.cell(row=2, column=col).value)

        # 生成类代码
        class_code = generate_class_code(sheet_name, headers, types, namespace)

        # 确定文件名
        class_name = to_pascal_case(sheet_name)
        if class_name.endswith('Config'):
            class_name = class_name[:-6]

        file_name = f'{class_name}.cs'
        file_path = os.path.join(output_dir, file_name)

        # 写入文件
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(class_code)

        generated_files.append(file_name)

        # 生成管理器（如果需要）
        if generate_manager:
            manager_code = generate_manager_code(class_name, sheet_name, namespace)
            manager_file_name = f'{class_name}Manager.cs'
            manager_file_path = os.path.join(output_dir, manager_file_name)

            with open(manager_file_path, 'w', encoding='utf-8') as f:
                f.write(manager_code)

            generated_files.append(manager_file_name)

    return generated_files


def main(
    file_name: Optional[str] = None,
    output_dir: Optional[str] = None,
    namespace: str = 'Game.Config',
    generate_manager: bool = True
):
    """
    根据 Excel 表头生成 C# 类

    Args:
        file_name: Excel 文件名，不填则处理所有文件
        output_dir: 输出目录
        namespace: 命名空间
        generate_manager: 是否生成管理器类
    """
    script_dir = os.path.dirname(os.path.abspath(__file__))
    excel_dir = os.path.join(script_dir, 'excel')

    if output_dir is None:
        output_dir = os.path.join(script_dir, '../Assets/Data/Scripts/Config')

    # 保持相对路径，如果需要绝对路径可以取消注释下面这行
    # output_dir = os.path.abspath(output_dir)

    os.makedirs(output_dir, exist_ok=True)

    print('=' * 60)
    print('Excel to C# Class Generator')
    print('=' * 60)
    print(f'Output directory: {output_dir}')
    print(f'Namespace: {namespace}')
    print(f'Generate Managers: {generate_manager}')
    print('=' * 60)

    # 确定要处理的文件
    if file_name:
        excel_files = [file_name]
        print(f'Mode: Single file ({file_name})')
    else:
        excel_files = [f for f in os.listdir(excel_dir) if f.endswith('.xlsx') and not f.startswith('.~')]
        print(f'Mode: Batch export ({len(excel_files)} files)')

    print('=' * 60)

    success_count = 0
    total_generated = 0

    for excel_file in excel_files:
        if not excel_file.endswith('.xlsx'):
            excel_file += '.xlsx'

        excel_path = os.path.join(excel_dir, excel_file)
        if os.path.exists(excel_path):
            print(f'Processing: {excel_file}...', end=' ', flush=True)
            try:
                generated = process_excel_file(excel_path, output_dir, namespace, generate_manager)
                print(f'OK ({len(generated)} files generated)')
                print(f'  Generated: {", ".join(generated)}')
                success_count += 1
                total_generated += len(generated)
            except Exception as e:
                print(f'FAILED: {e}')
                import traceback
                traceback.print_exc()
        else:
            print(f'File not found: {excel_path}')

    print('=' * 60)
    print(f'Done! Success: {success_count}/{len(excel_files)} files')
    print(f'Total files generated: {total_generated}')
    print('=' * 60)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser(description='根据 Excel 表头生成 C# 类')
    parser.add_argument('-f', '--file', help='指定 Excel 文件名')
    parser.add_argument('-o', '--output', help='输出目录')
    parser.add_argument('-n', '--namespace', default='Data.Config', help='命名空间（默认: Game.Config）')
    parser.add_argument('--no-manager', action='store_true', help='不生成管理器类')

    args = parser.parse_args()

    main(
        file_name=args.file,
        output_dir=args.output,
        namespace=args.namespace,
        generate_manager=False
    )
